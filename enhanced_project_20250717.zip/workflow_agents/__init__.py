
"""
AI-Powered Agentic Workflow for Project Management
Workflow Agents Package

This package contains seven specialized agents for project management:
1. ProjectManagerAgent - Orchestrates overall project management tasks
2. AugmentedPromptAgent - Enhances prompts with context and structure
3. KnowledgeAugmentedPromptAgent - Integrates domain knowledge into prompts
4. RAGKnowledgePromptAgent - Uses retrieval-augmented generation
5. EvaluationAgent - Evaluates and scores project deliverables
6. RoutingAgent - Routes tasks to appropriate specialized agents
7. ActionPlanningAgent - Creates detailed action plans for project tasks
"""

from .project_manager_agent import ProjectManagerAgent
from .augmented_prompt_agent import AugmentedPromptAgent
from .knowledge_augmented_prompt_agent import KnowledgeAugmentedPromptAgent
from .rag_knowledge_prompt_agent import RAGKnowledgePromptAgent
from .evaluation_agent import EvaluationAgent
from .routing_agent import RoutingAgent
from .action_planning_agent import ActionPlanningAgent

__all__ = [
    "ProjectManagerAgent",
    "AugmentedPromptAgent", 
    "KnowledgeAugmentedPromptAgent",
    "RAGKnowledgePromptAgent",
    "EvaluationAgent",
    "RoutingAgent",
    "ActionPlanningAgent"
]

__version__ = "1.0.0"
