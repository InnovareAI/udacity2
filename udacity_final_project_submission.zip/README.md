# AI-Powered Agentic Workflow for Project Management

## Project Overview

This project implements a comprehensive AI-powered agentic workflow system for project management at InnovateNext Solutions. The system consists of seven specialized AI agents that work together to handle various aspects of project management, from planning and execution to evaluation and optimization.

## Architecture

### Phase 1: Agent Library (`workflow_agents/`)

The system includes seven specialized agents:

1. **ProjectManagerAgent** - Orchestrates overall project management tasks
2. **AugmentedPromptAgent** - Enhances prompts with context and structure
3. **KnowledgeAugmentedPromptAgent** - Integrates domain knowledge into prompts
4. **RAGKnowledgePromptAgent** - Uses retrieval-augmented generation for knowledge integration
5. **EvaluationAgent** - Evaluates and scores project deliverables
6. **RoutingAgent** - Routes tasks to appropriate specialized agents
7. **ActionPlanningAgent** - Creates detailed action plans for project tasks

### Phase 2: Workflow Orchestration (`agentic_workflow.py`)

The main workflow orchestrator coordinates multiple agents to handle comprehensive project management tasks, including:

- Intelligent task routing based on request analysis
- Multi-agent collaboration for complex scenarios
- Quality evaluation and feedback loops
- Comprehensive reporting and documentation

## Features

- **Intelligent Task Routing**: Automatically determines the best agent(s) for each task
- **Multi-Agent Collaboration**: Agents work together for comprehensive solutions
- **Knowledge Integration**: Incorporates domain expertise and best practices
- **Quality Assurance**: Built-in evaluation and feedback mechanisms
- **Comprehensive Reporting**: Detailed workflow execution reports
- **Extensible Architecture**: Easy to add new agents and capabilities

## Installation

1. Clone or download the project files
2. Install required dependencies:
```bash
pip install -r requirements.txt
```

3. Set up your OpenAI API key:
```bash
export OPENAI_API_KEY="your-api-key-here"
```

## Usage

### Running the Main Workflow

```python
from agentic_workflow import AgenticProjectManagementWorkflow

# Initialize the workflow
workflow = AgenticProjectManagementWorkflow()

# Process a project request
results = workflow.process_project_request(
    "Create a project plan for developing a mobile app",
    context={"team_size": 5, "timeline": "3 months"}
)

# Generate report
report = workflow.generate_workflow_report(results)
print(report)
```

### Running the Email Router Demo

```bash
python agentic_workflow.py
```

This will execute the Email Router project demonstration, showing how the system handles a real-world project management scenario.

### Testing Individual Agents

```bash
python test_agents.py
```

This will run tests for all individual agents to ensure they're working correctly.

### Using Individual Agents

```python
from workflow_agents import ProjectManagerAgent, ActionPlanningAgent

# Use Project Manager Agent
pm_agent = ProjectManagerAgent()
response = pm_agent.create_project_plan("Develop a web application")

# Use Action Planning Agent
ap_agent = ActionPlanningAgent()
plan = ap_agent.create_development_plan("User authentication system")
```

## Project Structure

```
udacity_final_project/
├── workflow_agents/           # Phase 1: Agent Library
│   ├── __init__.py
│   ├── base_agent.py         # Base class for all agents
│   ├── project_manager_agent.py
│   ├── augmented_prompt_agent.py
│   ├── knowledge_augmented_prompt_agent.py
│   ├── rag_knowledge_prompt_agent.py
│   ├── evaluation_agent.py
│   ├── routing_agent.py
│   └── action_planning_agent.py
├── agentic_workflow.py       # Phase 2: Main workflow orchestrator
├── test_agents.py           # Agent testing suite
├── requirements.txt         # Python dependencies
└── README.md               # This file
```

## Key Components

### Base Agent Class
All agents inherit from `BaseAgent` which provides:
- OpenAI API integration
- Standardized response format (`AgentResponse`)
- Confidence scoring
- Error handling

### Workflow Orchestration
The main workflow supports multiple execution patterns:
- **Project Management Workflow**: Focus on PM tasks
- **Action Planning Workflow**: Detailed task breakdown
- **Evaluation Workflow**: Quality assessment and improvement
- **Comprehensive Workflow**: Full multi-agent collaboration

### Quality Assurance
- Built-in confidence scoring for all agent responses
- Comprehensive evaluation of outputs
- Structured feedback and improvement recommendations

## Example Use Cases

1. **Project Planning**: Create comprehensive project plans with timelines, resources, and risk assessments
2. **Task Management**: Break down complex tasks into actionable steps
3. **Quality Evaluation**: Assess project deliverables and provide improvement recommendations
4. **Knowledge Integration**: Enhance decisions with domain expertise and best practices
5. **Workflow Optimization**: Route tasks efficiently and coordinate multi-agent responses

## Configuration

### Environment Variables
- `OPENAI_API_KEY`: Your OpenAI API key (defaults to Vocareum key if not set)

### Customization
- Modify agent capabilities in individual agent files
- Adjust workflow patterns in `agentic_workflow.py`
- Add new agents by extending `BaseAgent` class
- Customize knowledge bases in knowledge-augmented agents

## Performance and Scalability

- Agents use efficient OpenAI API calls with appropriate temperature settings
- Confidence scoring helps identify high-quality responses
- Modular architecture allows for easy scaling and modification
- Built-in error handling and fallback mechanisms

## Testing

The project includes comprehensive testing:
- Individual agent functionality tests
- Workflow integration tests
- Error handling validation
- Performance benchmarking

Run tests with:
```bash
python test_agents.py
```

## Future Enhancements

- Integration with external project management tools (Jira, Asana)
- Real-time collaboration features
- Advanced analytics and reporting
- Custom agent training for specific domains
- Web interface for easier interaction

## Contributing

To add new agents or enhance existing functionality:
1. Extend the `BaseAgent` class
2. Implement the `process()` method
3. Add appropriate tests
4. Update the workflow orchestrator as needed

## License

This project is developed for educational purposes as part of the Udacity AI course.

## Support

For questions or issues, please refer to the course materials or contact the development team.
