
"""
AI-Powered Agentic Workflow for Project Management
Phase 2: Main Workflow Implementation

This script orchestrates multiple AI agents to handle project management tasks
for InnovateNext Solutions, starting with the Email Router project.
"""

import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime
from workflow_agents import (
    ProjectManagerAgent,
    AugmentedPromptAgent,
    KnowledgeAugmentedPromptAgent,
    RAGKnowledgePromptAgent,
    EvaluationAgent,
    RoutingAgent,
    ActionPlanningAgent
)

class AgenticProjectManagementWorkflow:
    """
    Main workflow orchestrator that coordinates multiple AI agents
    to handle comprehensive project management tasks.
    """
    
    def __init__(self, api_key: Optional[str] = None):
        """Initialize the workflow with all required agents"""
        self.api_key = api_key or os.getenv("OPENAI_API_KEY", "voc-122935425515987435402666873764590c62.49926411")
        
        # Initialize all agents
        self.project_manager = ProjectManagerAgent(self.api_key)
        self.augmented_prompt = AugmentedPromptAgent(self.api_key)
        self.knowledge_augmented = KnowledgeAugmentedPromptAgent(self.api_key)
        self.rag_knowledge = RAGKnowledgePromptAgent(self.api_key)
        self.evaluation = EvaluationAgent(self.api_key)
        self.routing = RoutingAgent(self.api_key)
        self.action_planning = ActionPlanningAgent(self.api_key)
        
        # Workflow state
        self.workflow_history = []
        self.current_project = None
        
    def process_project_request(self, request: str, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Main entry point for processing project management requests.
        Uses routing agent to determine optimal workflow path.
        """
        print(f"🚀 Processing project request: {request[:100]}...")
        
        # Step 1: Route the request to determine workflow strategy
        routing_response = self.routing.route_task(request, str(context or {}))
        print(f"📍 Routing recommendation: {routing_response.metadata['primary_agent']}")
        
        # Step 2: Based on routing, execute appropriate workflow
        primary_agent = routing_response.metadata['primary_agent']
        
        if primary_agent == 'ProjectManagerAgent':
            return self._execute_project_management_workflow(request, context)
        elif primary_agent == 'ActionPlanningAgent':
            return self._execute_action_planning_workflow(request, context)
        elif primary_agent == 'EvaluationAgent':
            return self._execute_evaluation_workflow(request, context)
        else:
            # Default to comprehensive project management workflow
            return self._execute_comprehensive_workflow(request, context)
    
    def _execute_project_management_workflow(self, request: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Execute project management focused workflow"""
        print("🎯 Executing Project Management Workflow")
        
        results = {
            'workflow_type': 'project_management',
            'timestamp': datetime.now().isoformat(),
            'request': request,
            'steps': []
        }
        
        # Step 1: Enhance the request with project management context
        enhanced_prompt = self.knowledge_augmented.add_project_management_knowledge(request)
        results['steps'].append({
            'step': 'knowledge_enhancement',
            'agent': 'KnowledgeAugmentedPromptAgent',
            'output': enhanced_prompt.content,
            'confidence': enhanced_prompt.confidence_score
        })
        
        # Step 2: Generate comprehensive project management response
        pm_response = self.project_manager.process({
            'task_type': 'comprehensive_planning',
            'project_details': enhanced_prompt.content,
            'requirements': str(context or {}),
            'timeline': 'To be determined based on analysis'
        })
        results['steps'].append({
            'step': 'project_management_analysis',
            'agent': 'ProjectManagerAgent',
            'output': pm_response.content,
            'confidence': pm_response.confidence_score
        })
        
        # Step 3: Create detailed action plan
        action_plan = self.action_planning.create_project_plan(
            goal=request,
            project_type='project_management'
        )
        results['steps'].append({
            'step': 'action_planning',
            'agent': 'ActionPlanningAgent',
            'output': action_plan.content,
            'confidence': action_plan.confidence_score
        })
        
        # Step 4: Evaluate the overall response quality
        evaluation_input = f"Project Management Response: {pm_response.content}\n\nAction Plan: {action_plan.content}"
        evaluation = self.evaluation.evaluate_project_deliverable(evaluation_input)
        results['steps'].append({
            'step': 'quality_evaluation',
            'agent': 'EvaluationAgent',
            'output': evaluation.content,
            'confidence': evaluation.confidence_score
        })
        
        # Calculate overall workflow confidence
        confidences = [step['confidence'] for step in results['steps']]
        results['overall_confidence'] = sum(confidences) / len(confidences)
        
        return results
    
    def _execute_action_planning_workflow(self, request: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Execute action planning focused workflow"""
        print("📋 Executing Action Planning Workflow")
        
        results = {
            'workflow_type': 'action_planning',
            'timestamp': datetime.now().isoformat(),
            'request': request,
            'steps': []
        }
        
        # Step 1: Enhance prompt for better action planning
        enhanced_prompt = self.augmented_prompt.enhance_for_project_management(request)
        results['steps'].append({
            'step': 'prompt_enhancement',
            'agent': 'AugmentedPromptAgent',
            'output': enhanced_prompt.content,
            'confidence': enhanced_prompt.confidence_score
        })
        
        # Step 2: Add domain knowledge
        knowledge_enhanced = self.knowledge_augmented.add_project_management_knowledge(enhanced_prompt.content)
        results['steps'].append({
            'step': 'knowledge_integration',
            'agent': 'KnowledgeAugmentedPromptAgent',
            'output': knowledge_enhanced.content,
            'confidence': knowledge_enhanced.confidence_score
        })
        
        # Step 3: Create detailed action plan
        action_plan = self.action_planning.process({
            'goal': knowledge_enhanced.content,
            'project_type': context.get('project_type', 'project_management'),
            'complexity': context.get('complexity', 'medium'),
            'team_size': context.get('team_size', 5)
        })
        results['steps'].append({
            'step': 'action_plan_creation',
            'agent': 'ActionPlanningAgent',
            'output': action_plan.content,
            'confidence': action_plan.confidence_score
        })
        
        # Step 4: Evaluate the action plan
        evaluation = self.evaluation.evaluate_project_deliverable(action_plan.content)
        results['steps'].append({
            'step': 'plan_evaluation',
            'agent': 'EvaluationAgent',
            'output': evaluation.content,
            'confidence': evaluation.confidence_score
        })
        
        confidences = [step['confidence'] for step in results['steps']]
        results['overall_confidence'] = sum(confidences) / len(confidences)
        
        return results
    
    def _execute_evaluation_workflow(self, request: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Execute evaluation focused workflow"""
        print("📊 Executing Evaluation Workflow")
        
        results = {
            'workflow_type': 'evaluation',
            'timestamp': datetime.now().isoformat(),
            'request': request,
            'steps': []
        }
        
        # Step 1: Enhance evaluation prompt
        enhanced_prompt = self.augmented_prompt.process({
            'original_prompt': request,
            'task_domain': 'evaluation',
            'target_audience': 'project_managers',
            'enhancement_type': 'evaluation_focused'
        })
        results['steps'].append({
            'step': 'evaluation_prompt_enhancement',
            'agent': 'AugmentedPromptAgent',
            'output': enhanced_prompt.content,
            'confidence': enhanced_prompt.confidence_score
        })
        
        # Step 2: Perform comprehensive evaluation
        evaluation_type = context.get('evaluation_type', 'project_deliverable')
        evaluation = self.evaluation.process({
            'item_to_evaluate': enhanced_prompt.content,
            'evaluation_type': evaluation_type,
            'scoring_scale': '1-10'
        })
        results['steps'].append({
            'step': 'comprehensive_evaluation',
            'agent': 'EvaluationAgent',
            'output': evaluation.content,
            'confidence': evaluation.confidence_score
        })
        
        # Step 3: Generate improvement action plan based on evaluation
        improvement_plan = self.action_planning.break_down_task(
            f"Address evaluation findings: {evaluation.content}",
            context=str(context or {})
        )
        results['steps'].append({
            'step': 'improvement_planning',
            'agent': 'ActionPlanningAgent',
            'output': improvement_plan.content,
            'confidence': improvement_plan.confidence_score
        })
        
        confidences = [step['confidence'] for step in results['steps']]
        results['overall_confidence'] = sum(confidences) / len(confidences)
        
        return results
    
    def _execute_comprehensive_workflow(self, request: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Execute comprehensive multi-agent workflow"""
        print("🔄 Executing Comprehensive Multi-Agent Workflow")
        
        results = {
            'workflow_type': 'comprehensive',
            'timestamp': datetime.now().isoformat(),
            'request': request,
            'steps': []
        }
        
        # Step 1: Enhance prompt with context and structure
        enhanced_prompt = self.augmented_prompt.enhance_for_project_management(request)
        results['steps'].append({
            'step': 'prompt_enhancement',
            'agent': 'AugmentedPromptAgent',
            'output': enhanced_prompt.content,
            'confidence': enhanced_prompt.confidence_score
        })
        
        # Step 2: Add domain knowledge
        knowledge_enhanced = self.knowledge_augmented.add_project_management_knowledge(enhanced_prompt.content)
        results['steps'].append({
            'step': 'knowledge_enhancement',
            'agent': 'KnowledgeAugmentedPromptAgent',
            'output': knowledge_enhanced.content,
            'confidence': knowledge_enhanced.confidence_score
        })
        
        # Step 3: Retrieve additional knowledge using RAG
        rag_enhanced = self.rag_knowledge.enhance_with_project_knowledge(knowledge_enhanced.content)
        results['steps'].append({
            'step': 'rag_knowledge_retrieval',
            'agent': 'RAGKnowledgePromptAgent',
            'output': rag_enhanced.content,
            'confidence': rag_enhanced.confidence_score
        })
        
        # Step 4: Generate project management response
        pm_response = self.project_manager.process({
            'task_type': 'comprehensive_analysis',
            'project_details': rag_enhanced.content,
            'requirements': str(context or {}),
            'timeline': 'Flexible based on requirements'
        })
        results['steps'].append({
            'step': 'project_management_response',
            'agent': 'ProjectManagerAgent',
            'output': pm_response.content,
            'confidence': pm_response.confidence_score
        })
        
        # Step 5: Create action plan
        action_plan = self.action_planning.create_project_plan(pm_response.content)
        results['steps'].append({
            'step': 'action_planning',
            'agent': 'ActionPlanningAgent',
            'output': action_plan.content,
            'confidence': action_plan.confidence_score
        })
        
        # Step 6: Evaluate overall quality
        combined_output = f"PM Response: {pm_response.content}\n\nAction Plan: {action_plan.content}"
        evaluation = self.evaluation.evaluate_project_deliverable(combined_output)
        results['steps'].append({
            'step': 'quality_evaluation',
            'agent': 'EvaluationAgent',
            'output': evaluation.content,
            'confidence': evaluation.confidence_score
        })
        
        confidences = [step['confidence'] for step in results['steps']]
        results['overall_confidence'] = sum(confidences) / len(confidences)
        
        return results
    
    def handle_email_router_project(self) -> Dict[str, Any]:
        """
        Handle the specific Email Router project as mentioned in the requirements.
        This demonstrates the workflow with a concrete use case.
        """
        print("📧 Processing Email Router Project for InnovateNext Solutions")
        
        email_router_request = """
        InnovateNext Solutions needs to implement an Email Router system for their project management workflow.
        
        Project Requirements:
        - Automatically route incoming project-related emails to appropriate team members
        - Categorize emails by project type, priority, and department
        - Integrate with existing project management tools
        - Provide analytics and reporting on email routing patterns
        - Ensure security and compliance with company policies
        
        The system should handle high volume email processing and provide real-time routing decisions.
        Timeline: 3 months for MVP, 6 months for full implementation.
        Team: 5 developers, 2 project managers, 1 product manager.
        """
        
        context = {
            'project_type': 'software_development',
            'complexity': 'high',
            'team_size': 8,
            'timeline': '6 months',
            'company': 'InnovateNext Solutions'
        }
        
        return self.process_project_request(email_router_request, context)
    
    def generate_workflow_report(self, results: Dict[str, Any]) -> str:
        """Generate a comprehensive report of the workflow execution"""
        report = f"""
# AI-Powered Agentic Workflow Report
**Generated:** {results['timestamp']}
**Workflow Type:** {results['workflow_type']}
**Overall Confidence:** {results['overall_confidence']:.2f}

## Original Request
{results['request']}

## Workflow Execution Steps
"""
        
        for i, step in enumerate(results['steps'], 1):
            report += f"""
### Step {i}: {step['step'].replace('_', ' ').title()}
**Agent:** {step['agent']}
**Confidence:** {step['confidence']:.2f}

{step['output']}

---
"""
        
        report += f"""
## Summary
The workflow executed {len(results['steps'])} steps with an overall confidence of {results['overall_confidence']:.2f}.
Each step was processed by a specialized agent, ensuring comprehensive coverage of the project management requirements.

## Recommendations
Based on the workflow execution, the following recommendations are provided:
1. Review the action plan and adjust timelines as needed
2. Ensure all stakeholders are aligned with the proposed approach
3. Monitor progress regularly using the suggested metrics
4. Consider the identified risks and implement mitigation strategies
"""
        
        return report

def main():
    """Main function to demonstrate the agentic workflow"""
    print("🤖 Initializing AI-Powered Agentic Workflow for Project Management")
    
    # Initialize the workflow
    workflow = AgenticProjectManagementWorkflow()
    
    # Process the Email Router project
    results = workflow.handle_email_router_project()
    
    # Generate and display report
    report = workflow.generate_workflow_report(results)
    
    # Save results
    with open('workflow_results.json', 'w') as f:
        json.dump(results, f, indent=2)
    
    with open('workflow_report.md', 'w') as f:
        f.write(report)
    
    print(f"\n✅ Workflow completed successfully!")
    print(f"📊 Overall confidence: {results['overall_confidence']:.2f}")
    print(f"📁 Results saved to: workflow_results.json")
    print(f"📄 Report saved to: workflow_report.md")
    
    return results

if __name__ == "__main__":
    main()
