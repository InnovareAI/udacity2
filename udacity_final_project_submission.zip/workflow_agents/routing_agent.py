
"""
Routing Agent - Routes tasks to appropriate specialized agents
"""

from typing import Dict, Any, List, Optional, Tuple
from .base_agent import BaseAgent, AgentResponse
import json

class RoutingAgent(BaseAgent):
    """
    Routes tasks to appropriate specialized agents based on task analysis:
    - Analyzes incoming tasks and requests
    - Determines optimal agent routing strategy
    - Manages multi-agent workflows and coordination
    - Provides routing confidence and alternatives
    """
    
    def __init__(self, api_key: str = None):
        super().__init__(api_key)
        self.agent_capabilities = {
            'ProjectManagerAgent': {
                'specialties': ['project_planning', 'resource_allocation', 'timeline_management', 'risk_assessment', 'stakeholder_management'],
                'keywords': ['project', 'plan', 'timeline', 'milestone', 'resource', 'risk', 'stakeholder', 'budget', 'scope'],
                'confidence_threshold': 0.7
            },
            'AugmentedPromptAgent': {
                'specialties': ['prompt_enhancement', 'context_addition', 'structure_optimization', 'clarity_improvement'],
                'keywords': ['prompt', 'enhance', 'improve', 'structure', 'clarity', 'context', 'optimize'],
                'confidence_threshold': 0.8
            },
            'KnowledgeAugmentedPromptAgent': {
                'specialties': ['domain_knowledge_integration', 'best_practices', 'framework_application', 'expertise_addition'],
                'keywords': ['knowledge', 'expertise', 'best_practice', 'framework', 'methodology', 'domain', 'standard'],
                'confidence_threshold': 0.75
            },
            'RAGKnowledgePromptAgent': {
                'specialties': ['information_retrieval', 'knowledge_search', 'source_integration', 'fact_checking'],
                'keywords': ['retrieve', 'search', 'source', 'reference', 'lookup', 'find', 'information'],
                'confidence_threshold': 0.8
            },
            'EvaluationAgent': {
                'specialties': ['quality_assessment', 'scoring', 'feedback_generation', 'performance_evaluation'],
                'keywords': ['evaluate', 'assess', 'score', 'quality', 'feedback', 'review', 'grade', 'measure'],
                'confidence_threshold': 0.85
            },
            'ActionPlanningAgent': {
                'specialties': ['task_breakdown', 'action_planning', 'step_sequencing', 'implementation_strategy'],
                'keywords': ['action', 'plan', 'step', 'task', 'implement', 'execute', 'strategy', 'breakdown'],
                'confidence_threshold': 0.75
            }
        }
    
    def process(self, input_data: Dict[str, Any]) -> AgentResponse:
        """
        Process routing requests
        
        Args:
            input_data: Dictionary containing:
                - task_description: Description of the task to route
                - context: Additional context about the task
                - priority: Task priority level
                - constraints: Any routing constraints
        """
        task_description = input_data.get('task_description', '')
        context = input_data.get('context', '')
        priority = input_data.get('priority', 'medium')
        constraints = input_data.get('constraints', {})
        
        # Analyze task and determine routing
        routing_analysis = self._analyze_task_for_routing(task_description, context)
        primary_agent, confidence = self._determine_primary_agent(routing_analysis)
        alternative_agents = self._get_alternative_agents(routing_analysis, primary_agent)
        
        system_prompt = """You are an expert task routing specialist with deep understanding of agent capabilities and optimal workflow design.
        Your role is to analyze tasks and provide intelligent routing recommendations with detailed reasoning.
        
        Routing Principles:
        - Match task requirements to agent specialties
        - Consider task complexity and multi-agent coordination needs
        - Provide confidence scores and alternative options
        - Include workflow sequencing recommendations
        - Account for constraints and priorities"""
        
        user_prompt = f"""
        Task to Route: {task_description}
        Context: {context}
        Priority: {priority}
        Constraints: {constraints}
        
        Routing Analysis Results:
        Primary Agent Recommendation: {primary_agent} (Confidence: {confidence:.2f})
        Alternative Agents: {alternative_agents}
        
        Please provide a comprehensive routing recommendation including:
        1. Primary agent selection with reasoning
        2. Alternative routing options
        3. Multi-agent workflow suggestions if applicable
        4. Expected outcomes and success criteria
        5. Potential challenges and mitigation strategies
        """
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        response_content = self._call_openai(messages)
        
        return AgentResponse(
            success=True,
            content=response_content,
            metadata={
                "agent_type": "RoutingAgent",
                "primary_agent": primary_agent,
                "routing_confidence": confidence,
                "alternative_agents": alternative_agents,
                "task_analysis": routing_analysis,
                "priority": priority
            },
            confidence_score=confidence,
            reasoning=f"Analyzed task and recommended {primary_agent} based on capability matching and confidence scoring"
        )
    
    def _analyze_task_for_routing(self, task_description: str, context: str) -> Dict[str, Any]:
        """Analyze task characteristics for routing decisions"""
        combined_text = f"{task_description} {context}".lower()
        
        analysis = {
            'task_type': self._classify_task_type(combined_text),
            'complexity': self._assess_complexity(combined_text),
            'domain': self._identify_domain(combined_text),
            'keywords_found': self._extract_relevant_keywords(combined_text),
            'multi_agent_needed': self._assess_multi_agent_need(combined_text)
        }
        
        return analysis
    
    def _classify_task_type(self, text: str) -> str:
        """Classify the type of task"""
        task_indicators = {
            'planning': ['plan', 'strategy', 'roadmap', 'timeline', 'schedule'],
            'evaluation': ['evaluate', 'assess', 'review', 'score', 'measure'],
            'enhancement': ['improve', 'enhance', 'optimize', 'refine'],
            'analysis': ['analyze', 'examine', 'investigate', 'study'],
            'creation': ['create', 'build', 'develop', 'generate', 'design']
        }
        
        scores = {}
        for task_type, keywords in task_indicators.items():
            scores[task_type] = sum(1 for keyword in keywords if keyword in text)
        
        return max(scores, key=scores.get) if max(scores.values()) > 0 else 'general'
    
    def _assess_complexity(self, text: str) -> str:
        """Assess task complexity"""
        complexity_indicators = {
            'high': ['complex', 'comprehensive', 'detailed', 'multi-step', 'integration'],
            'medium': ['moderate', 'standard', 'typical', 'regular'],
            'low': ['simple', 'basic', 'quick', 'straightforward']
        }
        
        for level, indicators in complexity_indicators.items():
            if any(indicator in text for indicator in indicators):
                return level
        
        # Default assessment based on text length and structure
        if len(text) > 500:
            return 'high'
        elif len(text) > 200:
            return 'medium'
        else:
            return 'low'
    
    def _identify_domain(self, text: str) -> str:
        """Identify the domain of the task"""
        domain_keywords = {
            'project_management': ['project', 'milestone', 'timeline', 'resource', 'stakeholder'],
            'software_development': ['code', 'development', 'programming', 'software', 'application'],
            'ai_ml': ['ai', 'machine learning', 'model', 'algorithm', 'data science'],
            'documentation': ['document', 'documentation', 'manual', 'guide', 'specification'],
            'evaluation': ['evaluate', 'assessment', 'quality', 'performance', 'metrics']
        }
        
        domain_scores = {}
        for domain, keywords in domain_keywords.items():
            domain_scores[domain] = sum(1 for keyword in keywords if keyword in text)
        
        return max(domain_scores, key=domain_scores.get) if max(domain_scores.values()) > 0 else 'general'
    
    def _extract_relevant_keywords(self, text: str) -> List[str]:
        """Extract keywords relevant for routing"""
        all_keywords = []
        for agent_info in self.agent_capabilities.values():
            all_keywords.extend(agent_info['keywords'])
        
        found_keywords = [keyword for keyword in all_keywords if keyword in text]
        return list(set(found_keywords))  # Remove duplicates
    
    def _assess_multi_agent_need(self, text: str) -> bool:
        """Assess if task requires multiple agents"""
        multi_agent_indicators = [
            'comprehensive', 'end-to-end', 'complete', 'full', 'integrated',
            'multiple', 'various', 'different', 'several'
        ]
        
        return any(indicator in text for indicator in multi_agent_indicators)
    
    def _determine_primary_agent(self, analysis: Dict[str, Any]) -> Tuple[str, float]:
        """Determine the primary agent for the task"""
        agent_scores = {}
        
        for agent_name, capabilities in self.agent_capabilities.items():
            score = 0
            
            # Score based on keyword matches
            keyword_matches = sum(1 for keyword in capabilities['keywords'] 
                                if keyword in analysis['keywords_found'])
            score += keyword_matches * 0.4
            
            # Score based on specialty alignment
            task_type = analysis['task_type']
            if any(task_type in specialty for specialty in capabilities['specialties']):
                score += 0.3
            
            # Score based on domain alignment
            domain = analysis['domain']
            if domain in ' '.join(capabilities['specialties']):
                score += 0.2
            
            # Normalize score
            max_possible_score = len(capabilities['keywords']) * 0.4 + 0.5
            normalized_score = min(score / max_possible_score, 1.0) if max_possible_score > 0 else 0
            
            agent_scores[agent_name] = normalized_score
        
        # Get agent with highest score
        primary_agent = max(agent_scores, key=agent_scores.get)
        confidence = agent_scores[primary_agent]
        
        return primary_agent, confidence
    
    def _get_alternative_agents(self, analysis: Dict[str, Any], primary_agent: str) -> List[Dict[str, Any]]:
        """Get alternative agent recommendations"""
        agent_scores = {}
        
        for agent_name, capabilities in self.agent_capabilities.items():
            if agent_name == primary_agent:
                continue
                
            score = 0
            keyword_matches = sum(1 for keyword in capabilities['keywords'] 
                                if keyword in analysis['keywords_found'])
            score += keyword_matches * 0.4
            
            if score > 0:
                agent_scores[agent_name] = score
        
        # Sort and return top alternatives
        sorted_alternatives = sorted(agent_scores.items(), key=lambda x: x[1], reverse=True)
        return [{"agent": agent, "score": score} for agent, score in sorted_alternatives[:3]]
    
    def route_task(self, task_description: str, context: str = "") -> AgentResponse:
        """Route a specific task"""
        return self.process({
            'task_description': task_description,
            'context': context,
            'priority': 'medium'
        })
    
    def get_agent_capabilities(self) -> Dict[str, Any]:
        """Get information about available agents and their capabilities"""
        return self.agent_capabilities
