
"""
Evaluation Agent - Evaluates and scores project deliverables
"""

from typing import Dict, Any, List, Optional
from .base_agent import BaseAgent, AgentResponse
import json

class EvaluationAgent(BaseAgent):
    """
    Evaluates and scores project deliverables, outputs, and performance:
    - Assesses quality against defined criteria
    - Provides quantitative and qualitative scoring
    - Identifies areas for improvement
    - Generates detailed evaluation reports
    """
    
    def __init__(self, api_key: str = None):
        super().__init__(api_key)
        self.evaluation_criteria = {
            'code_quality': {
                'readability': {'weight': 0.25, 'description': 'Code clarity and documentation'},
                'functionality': {'weight': 0.30, 'description': 'Correctness and completeness'},
                'maintainability': {'weight': 0.20, 'description': 'Ease of modification and extension'},
                'performance': {'weight': 0.15, 'description': 'Efficiency and optimization'},
                'security': {'weight': 0.10, 'description': 'Security best practices'}
            },
            'project_deliverable': {
                'completeness': {'weight': 0.30, 'description': 'All requirements addressed'},
                'quality': {'weight': 0.25, 'description': 'Overall quality and polish'},
                'timeliness': {'weight': 0.20, 'description': 'Delivered on schedule'},
                'stakeholder_satisfaction': {'weight': 0.15, 'description': 'Meets stakeholder expectations'},
                'innovation': {'weight': 0.10, 'description': 'Creative and innovative approach'}
            },
            'documentation': {
                'clarity': {'weight': 0.30, 'description': 'Clear and understandable'},
                'completeness': {'weight': 0.25, 'description': 'Comprehensive coverage'},
                'accuracy': {'weight': 0.20, 'description': 'Factually correct and up-to-date'},
                'usability': {'weight': 0.15, 'description': 'Easy to use and navigate'},
                'maintenance': {'weight': 0.10, 'description': 'Easy to maintain and update'}
            }
        }
    
    def process(self, input_data: Dict[str, Any]) -> AgentResponse:
        """
        Process evaluation requests
        
        Args:
            input_data: Dictionary containing:
                - item_to_evaluate: The item/content to evaluate
                - evaluation_type: Type of evaluation (code_quality, project_deliverable, documentation)
                - custom_criteria: Optional custom evaluation criteria
                - scoring_scale: Scoring scale (1-5, 1-10, percentage)
        """
        item_to_evaluate = input_data.get('item_to_evaluate', '')
        evaluation_type = input_data.get('evaluation_type', 'project_deliverable')
        custom_criteria = input_data.get('custom_criteria', {})
        scoring_scale = input_data.get('scoring_scale', '1-10')
        
        # Get evaluation criteria
        criteria = custom_criteria if custom_criteria else self.evaluation_criteria.get(evaluation_type, {})
        
        system_prompt = f"""You are an expert evaluator specializing in {evaluation_type} assessment. 
        Your role is to provide comprehensive, objective evaluations with detailed scoring and feedback.
        
        Evaluation Criteria for {evaluation_type}:
        {self._format_criteria(criteria)}
        
        Scoring Guidelines:
        - Use {scoring_scale} scale
        - Provide specific examples and evidence
        - Include both strengths and areas for improvement
        - Give actionable recommendations
        - Maintain objectivity and fairness
        
        Output Format:
        1. Overall Score: [X/{scoring_scale.split('-')[1]}]
        2. Detailed Scoring by Criteria
        3. Strengths Identified
        4. Areas for Improvement
        5. Specific Recommendations
        6. Summary Assessment"""
        
        user_prompt = f"""
        Please evaluate the following {evaluation_type}:
        
        Item to Evaluate:
        {item_to_evaluate}
        
        Provide a comprehensive evaluation following the specified criteria and format.
        """
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        response_content = self._call_openai(messages, temperature=0.3)  # Lower temperature for more consistent evaluation
        
        # Extract scores and calculate overall confidence
        evaluation_scores = self._extract_scores(response_content, scoring_scale)
        confidence = self._calculate_evaluation_confidence(evaluation_scores, response_content)
        
        return AgentResponse(
            success=True,
            content=response_content,
            metadata={
                "agent_type": "EvaluationAgent",
                "evaluation_type": evaluation_type,
                "scoring_scale": scoring_scale,
                "criteria_used": list(criteria.keys()),
                "extracted_scores": evaluation_scores,
                "overall_score": evaluation_scores.get('overall', 0)
            },
            confidence_score=confidence,
            reasoning=f"Conducted {evaluation_type} evaluation using {len(criteria)} criteria with {scoring_scale} scoring scale"
        )
    
    def _format_criteria(self, criteria: Dict[str, Dict[str, Any]]) -> str:
        """Format evaluation criteria for prompt"""
        formatted = []
        for criterion, details in criteria.items():
            weight = details.get('weight', 0) * 100
            description = details.get('description', '')
            formatted.append(f"- {criterion.title()} ({weight:.0f}%): {description}")
        return "\n".join(formatted)
    
    def _extract_scores(self, response: str, scoring_scale: str) -> Dict[str, float]:
        """Extract numerical scores from evaluation response"""
        scores = {}
        lines = response.split('\n')
        
        # Simple pattern matching for scores
        for line in lines:
            if 'overall score' in line.lower() or 'total score' in line.lower():
                # Extract number from line
                import re
                numbers = re.findall(r'\d+(?:\.\d+)?', line)
                if numbers:
                    scores['overall'] = float(numbers[0])
        
        # If no overall score found, estimate based on content
        if 'overall' not in scores:
            max_score = int(scoring_scale.split('-')[1])
            if 'excellent' in response.lower() or 'outstanding' in response.lower():
                scores['overall'] = max_score * 0.9
            elif 'good' in response.lower() or 'satisfactory' in response.lower():
                scores['overall'] = max_score * 0.7
            elif 'poor' in response.lower() or 'inadequate' in response.lower():
                scores['overall'] = max_score * 0.4
            else:
                scores['overall'] = max_score * 0.6
        
        return scores
    
    def _calculate_evaluation_confidence(self, scores: Dict[str, float], response: str) -> float:
        """Calculate confidence in evaluation quality"""
        base_confidence = 0.8  # High base confidence for evaluation tasks
        
        # Adjust based on response structure and detail
        structure_indicators = ['strengths', 'improvement', 'recommendation', 'score']
        structure_score = sum(1 for indicator in structure_indicators if indicator in response.lower()) / len(structure_indicators)
        
        # Adjust based on score presence
        score_confidence = 1.0 if scores else 0.5
        
        return (base_confidence + structure_score + score_confidence) / 3
    
    def evaluate_code_quality(self, code: str) -> AgentResponse:
        """Evaluate code quality"""
        return self.process({
            'item_to_evaluate': code,
            'evaluation_type': 'code_quality',
            'scoring_scale': '1-10'
        })
    
    def evaluate_project_deliverable(self, deliverable_description: str) -> AgentResponse:
        """Evaluate project deliverable"""
        return self.process({
            'item_to_evaluate': deliverable_description,
            'evaluation_type': 'project_deliverable',
            'scoring_scale': '1-10'
        })
    
    def evaluate_documentation(self, documentation: str) -> AgentResponse:
        """Evaluate documentation quality"""
        return self.process({
            'item_to_evaluate': documentation,
            'evaluation_type': 'documentation',
            'scoring_scale': '1-10'
        })
