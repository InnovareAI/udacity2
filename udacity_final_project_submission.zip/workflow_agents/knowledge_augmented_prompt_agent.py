
"""
Knowledge Augmented Prompt Agent - Integrates domain knowledge into prompts
"""

from typing import Dict, Any, List
from .base_agent import BaseAgent, AgentResponse

class KnowledgeAugmentedPromptAgent(BaseAgent):
    """
    Integrates domain-specific knowledge into prompts:
    - Adds relevant domain expertise and best practices
    - Incorporates industry standards and methodologies
    - Includes relevant frameworks and models
    - Provides context-aware knowledge integration
    """
    
    def __init__(self, api_key: str = None):
        super().__init__(api_key)
        self.knowledge_base = {
            'project_management': {
                'frameworks': ['Agile', 'Scrum', 'Kanban', 'Waterfall', 'PRINCE2'],
                'methodologies': ['PMI', 'PMBOK', 'Lean', 'Six Sigma'],
                'tools': ['Jira', 'Asana', 'Trello', 'Microsoft Project'],
                'best_practices': [
                    'Define clear project scope and objectives',
                    'Establish realistic timelines and milestones',
                    'Implement regular stakeholder communication',
                    'Conduct risk assessments and mitigation planning',
                    'Monitor progress with KPIs and metrics'
                ]
            },
            'software_development': {
                'methodologies': ['Agile', 'DevOps', 'CI/CD', 'TDD', 'BDD'],
                'frameworks': ['React', 'Angular', 'Vue', 'Django', 'Flask', 'Spring'],
                'best_practices': [
                    'Follow coding standards and conventions',
                    'Implement comprehensive testing strategies',
                    'Use version control effectively',
                    'Document code and architecture decisions',
                    'Conduct regular code reviews'
                ]
            },
            'ai_ml': {
                'frameworks': ['TensorFlow', 'PyTorch', 'Scikit-learn', 'Keras'],
                'methodologies': ['CRISP-DM', 'KDD', 'MLOps'],
                'best_practices': [
                    'Ensure data quality and preprocessing',
                    'Select appropriate algorithms and models',
                    'Implement proper validation and testing',
                    'Monitor model performance and drift',
                    'Maintain ethical AI practices'
                ]
            }
        }
    
    def process(self, input_data: Dict[str, Any]) -> AgentResponse:
        """
        Process knowledge augmentation requests
        
        Args:
            input_data: Dictionary containing:
                - prompt: The base prompt to enhance with knowledge
                - domain: Knowledge domain to integrate
                - knowledge_depth: Level of knowledge integration (basic, intermediate, expert)
                - specific_topics: Specific topics or areas to focus on
        """
        prompt = input_data.get('prompt', '')
        domain = input_data.get('domain', 'general')
        knowledge_depth = input_data.get('knowledge_depth', 'intermediate')
        specific_topics = input_data.get('specific_topics', [])
        
        # Get relevant knowledge from knowledge base
        domain_knowledge = self.knowledge_base.get(domain, {})
        
        system_prompt = f"""You are an expert knowledge integration specialist with deep expertise in {domain}. 
        Your role is to enhance prompts by integrating relevant domain knowledge, best practices, and industry standards.
        
        Available knowledge for {domain}:
        - Frameworks: {domain_knowledge.get('frameworks', [])}
        - Methodologies: {domain_knowledge.get('methodologies', [])}
        - Tools: {domain_knowledge.get('tools', [])}
        - Best Practices: {domain_knowledge.get('best_practices', [])}
        
        Integration approach for {knowledge_depth} level:
        - Include relevant frameworks and methodologies
        - Reference industry standards and best practices
        - Provide context-specific guidance
        - Add domain-specific terminology and concepts
        - Include practical examples and use cases"""
        
        user_prompt = f"""
        Please enhance the following prompt by integrating relevant {domain} knowledge:
        
        Original Prompt: {prompt}
        
        Knowledge Depth: {knowledge_depth}
        Specific Topics: {specific_topics}
        
        Create an enhanced version that incorporates domain expertise while maintaining clarity and actionability.
        """
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        response_content = self._call_openai(messages)
        confidence = self._calculate_confidence(response_content)
        
        return AgentResponse(
            success=True,
            content=response_content,
            metadata={
                "agent_type": "KnowledgeAugmentedPromptAgent",
                "domain": domain,
                "knowledge_depth": knowledge_depth,
                "integrated_knowledge": domain_knowledge,
                "specific_topics": specific_topics
            },
            confidence_score=confidence,
            reasoning=f"Integrated {domain} domain knowledge at {knowledge_depth} level with focus on {specific_topics}"
        )
    
    def add_project_management_knowledge(self, prompt: str) -> AgentResponse:
        """Add project management specific knowledge to prompt"""
        return self.process({
            'prompt': prompt,
            'domain': 'project_management',
            'knowledge_depth': 'expert',
            'specific_topics': ['planning', 'execution', 'monitoring', 'risk_management']
        })
    
    def add_technical_knowledge(self, prompt: str, tech_domain: str = 'software_development') -> AgentResponse:
        """Add technical domain knowledge to prompt"""
        return self.process({
            'prompt': prompt,
            'domain': tech_domain,
            'knowledge_depth': 'intermediate',
            'specific_topics': ['best_practices', 'methodologies', 'tools']
        })
