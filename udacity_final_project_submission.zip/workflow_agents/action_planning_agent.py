
"""
Action Planning Agent - Creates detailed action plans for project tasks
"""

from typing import Dict, Any, List, Optional
from .base_agent import BaseAgent, AgentResponse
import json
from datetime import datetime, timedelta

class ActionPlanningAgent(BaseAgent):
    """
    Creates detailed action plans for project tasks:
    - Breaks down complex tasks into actionable steps
    - Sequences activities with dependencies
    - Estimates effort and timelines
    - Identifies required resources and skills
    - Provides implementation strategies
    """
    
    def __init__(self, api_key: str = None):
        super().__init__(api_key)
        self.planning_templates = {
            'software_development': {
                'phases': ['Analysis', 'Design', 'Implementation', 'Testing', 'Deployment'],
                'common_tasks': ['Requirements gathering', 'Architecture design', 'Code development', 'Unit testing', 'Integration testing', 'Documentation'],
                'effort_multipliers': {'Analysis': 0.15, 'Design': 0.20, 'Implementation': 0.40, 'Testing': 0.20, 'Deployment': 0.05}
            },
            'project_management': {
                'phases': ['Initiation', 'Planning', 'Execution', 'Monitoring', 'Closure'],
                'common_tasks': ['Stakeholder identification', 'Scope definition', 'Timeline creation', 'Resource allocation', 'Risk assessment', 'Progress tracking'],
                'effort_multipliers': {'Initiation': 0.10, 'Planning': 0.25, 'Execution': 0.50, 'Monitoring': 0.10, 'Closure': 0.05}
            },
            'ai_ml_project': {
                'phases': ['Data Collection', 'Data Preparation', 'Model Development', 'Evaluation', 'Deployment'],
                'common_tasks': ['Data sourcing', 'Data cleaning', 'Feature engineering', 'Model training', 'Model validation', 'Production deployment'],
                'effort_multipliers': {'Data Collection': 0.15, 'Data Preparation': 0.30, 'Model Development': 0.30, 'Evaluation': 0.15, 'Deployment': 0.10}
            }
        }
    
    def process(self, input_data: Dict[str, Any]) -> AgentResponse:
        """
        Process action planning requests
        
        Args:
            input_data: Dictionary containing:
                - goal: The main goal or objective
                - project_type: Type of project (software_development, project_management, ai_ml_project)
                - constraints: Time, resource, or other constraints
                - complexity: Project complexity level (low, medium, high)
                - team_size: Size of the team
        """
        goal = input_data.get('goal', '')
        project_type = input_data.get('project_type', 'project_management')
        constraints = input_data.get('constraints', {})
        complexity = input_data.get('complexity', 'medium')
        team_size = input_data.get('team_size', 3)
        
        # Get planning template
        template = self.planning_templates.get(project_type, self.planning_templates['project_management'])
        
        system_prompt = f"""You are an expert action planning specialist with extensive experience in {project_type}.
        Your role is to create comprehensive, actionable plans that break down complex goals into manageable steps.
        
        Planning Framework for {project_type}:
        - Phases: {template['phases']}
        - Common Tasks: {template['common_tasks']}
        - Effort Distribution: {template['effort_multipliers']}
        
        Planning Principles:
        - Break down goals into specific, measurable actions
        - Sequence tasks with clear dependencies
        - Estimate realistic timelines and effort
        - Identify required resources and skills
        - Include risk mitigation and contingency planning
        - Provide clear success criteria and milestones
        
        Output Format:
        1. Executive Summary
        2. Goal Breakdown and Success Criteria
        3. Detailed Action Plan with Phases
        4. Timeline and Milestones
        5. Resource Requirements
        6. Risk Assessment and Mitigation
        7. Implementation Strategy"""
        
        user_prompt = f"""
        Create a comprehensive action plan for the following:
        
        Goal: {goal}
        Project Type: {project_type}
        Complexity: {complexity}
        Team Size: {team_size}
        Constraints: {constraints}
        
        Provide a detailed, actionable plan that addresses all aspects of successful implementation.
        """
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        response_content = self._call_openai(messages, temperature=0.4)  # Slightly lower temperature for more structured planning
        
        # Extract plan structure and estimate timeline
        plan_analysis = self._analyze_plan_structure(response_content)
        confidence = self._calculate_planning_confidence(plan_analysis, complexity, team_size)
        
        return AgentResponse(
            success=True,
            content=response_content,
            metadata={
                "agent_type": "ActionPlanningAgent",
                "project_type": project_type,
                "complexity": complexity,
                "team_size": team_size,
                "plan_analysis": plan_analysis,
                "estimated_phases": len(template['phases']),
                "template_used": project_type
            },
            confidence_score=confidence,
            reasoning=f"Created {complexity} complexity action plan for {project_type} with {team_size} team members using structured planning methodology"
        )
    
    def _analyze_plan_structure(self, plan_content: str) -> Dict[str, Any]:
        """Analyze the structure and completeness of the generated plan"""
        analysis = {
            'has_phases': bool(any(phase_indicator in plan_content.lower() 
                                 for phase_indicator in ['phase', 'stage', 'step'])),
            'has_timeline': bool(any(time_indicator in plan_content.lower() 
                                   for time_indicator in ['timeline', 'schedule', 'duration', 'week', 'month'])),
            'has_resources': bool(any(resource_indicator in plan_content.lower() 
                                    for resource_indicator in ['resource', 'team', 'skill', 'tool'])),
            'has_risks': bool(any(risk_indicator in plan_content.lower() 
                                for risk_indicator in ['risk', 'challenge', 'mitigation', 'contingency'])),
            'has_milestones': bool(any(milestone_indicator in plan_content.lower() 
                                     for milestone_indicator in ['milestone', 'deliverable', 'checkpoint'])),
            'word_count': len(plan_content.split()),
            'structure_score': 0
        }
        
        # Calculate structure score
        structure_elements = ['has_phases', 'has_timeline', 'has_resources', 'has_risks', 'has_milestones']
        analysis['structure_score'] = sum(analysis[element] for element in structure_elements) / len(structure_elements)
        
        return analysis
    
    def _calculate_planning_confidence(self, plan_analysis: Dict[str, Any], complexity: str, team_size: int) -> float:
        """Calculate confidence in the planning quality"""
        base_confidence = 0.7
        
        # Adjust based on plan structure completeness
        structure_bonus = plan_analysis['structure_score'] * 0.2
        
        # Adjust based on content depth
        word_count = plan_analysis['word_count']
        depth_bonus = min(word_count / 1000, 0.1)  # Bonus for detailed plans
        
        # Adjust based on complexity alignment
        complexity_multiplier = {'low': 1.0, 'medium': 0.95, 'high': 0.9}
        complexity_factor = complexity_multiplier.get(complexity, 0.9)
        
        # Adjust based on team size appropriateness
        team_factor = 1.0 if 2 <= team_size <= 10 else 0.9
        
        final_confidence = (base_confidence + structure_bonus + depth_bonus) * complexity_factor * team_factor
        return min(final_confidence, 1.0)
    
    def create_project_plan(self, goal: str, project_type: str = 'project_management') -> AgentResponse:
        """Create a project plan for a specific goal"""
        return self.process({
            'goal': goal,
            'project_type': project_type,
            'complexity': 'medium',
            'team_size': 5
        })
    
    def create_development_plan(self, feature_description: str, team_size: int = 3) -> AgentResponse:
        """Create a software development plan"""
        return self.process({
            'goal': f"Develop feature: {feature_description}",
            'project_type': 'software_development',
            'complexity': 'medium',
            'team_size': team_size
        })
    
    def create_ai_project_plan(self, ai_goal: str, complexity: str = 'medium') -> AgentResponse:
        """Create an AI/ML project plan"""
        return self.process({
            'goal': ai_goal,
            'project_type': 'ai_ml_project',
            'complexity': complexity,
            'team_size': 4
        })
    
    def break_down_task(self, task_description: str, context: str = "") -> AgentResponse:
        """Break down a complex task into actionable steps"""
        combined_goal = f"{task_description}. Context: {context}" if context else task_description
        return self.process({
            'goal': combined_goal,
            'project_type': 'project_management',
            'complexity': 'low',
            'team_size': 1
        })
