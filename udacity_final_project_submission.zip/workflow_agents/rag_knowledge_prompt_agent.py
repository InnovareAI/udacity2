
"""
RAG Knowledge Prompt Agent - Uses retrieval-augmented generation for knowledge integration
"""

from typing import Dict, Any, List, Optional
from .base_agent import BaseAgent, AgentResponse
import json

class RAGKnowledgePromptAgent(BaseAgent):
    """
    Uses Retrieval-Augmented Generation (RAG) to enhance prompts with retrieved knowledge:
    - Retrieves relevant information from knowledge sources
    - Integrates retrieved content into prompts
    - Provides source attribution and confidence scoring
    - Supports multiple knowledge domains and sources
    """
    
    def __init__(self, api_key: str = None):
        super().__init__(api_key)
        # Simulated knowledge base for demonstration
        self.knowledge_sources = {
            'project_management_best_practices': [
                {
                    'content': 'Effective project planning requires clear scope definition, stakeholder identification, and realistic timeline estimation.',
                    'source': 'PMI PMBOK Guide',
                    'relevance_score': 0.95
                },
                {
                    'content': 'Risk management should be integrated throughout the project lifecycle, not just during planning phases.',
                    'source': 'Project Risk Management Handbook',
                    'relevance_score': 0.90
                },
                {
                    'content': 'Agile methodologies emphasize iterative development, continuous feedback, and adaptive planning.',
                    'source': 'Agile Project Management Guide',
                    'relevance_score': 0.88
                }
            ],
            'technical_documentation': [
                {
                    'content': 'API design should follow RESTful principles with clear resource naming and appropriate HTTP methods.',
                    'source': 'REST API Design Guidelines',
                    'relevance_score': 0.92
                },
                {
                    'content': 'Code documentation should explain the why, not just the what, providing context for future maintainers.',
                    'source': 'Clean Code Principles',
                    'relevance_score': 0.89
                }
            ],
            'ai_development': [
                {
                    'content': 'Model evaluation should include multiple metrics and consider both performance and fairness aspects.',
                    'source': 'AI Ethics and Evaluation Framework',
                    'relevance_score': 0.94
                },
                {
                    'content': 'Data preprocessing is crucial for model performance and should include outlier detection and feature scaling.',
                    'source': 'Machine Learning Best Practices',
                    'relevance_score': 0.91
                }
            ]
        }
    
    def process(self, input_data: Dict[str, Any]) -> AgentResponse:
        """
        Process RAG-enhanced prompt generation
        
        Args:
            input_data: Dictionary containing:
                - query: The original query or prompt
                - knowledge_domain: Domain to search for relevant knowledge
                - max_sources: Maximum number of sources to retrieve
                - min_relevance: Minimum relevance score for inclusion
        """
        query = input_data.get('query', '')
        knowledge_domain = input_data.get('knowledge_domain', 'project_management_best_practices')
        max_sources = input_data.get('max_sources', 3)
        min_relevance = input_data.get('min_relevance', 0.8)
        
        # Retrieve relevant knowledge
        retrieved_knowledge = self._retrieve_knowledge(query, knowledge_domain, max_sources, min_relevance)
        
        system_prompt = """You are an expert at integrating retrieved knowledge into prompts using RAG (Retrieval-Augmented Generation).
        Your role is to enhance prompts by incorporating relevant retrieved information while maintaining coherence and accuracy.
        
        Guidelines:
        - Integrate retrieved knowledge naturally into the prompt
        - Maintain source attribution where appropriate
        - Ensure retrieved information is relevant and accurate
        - Balance retrieved knowledge with original query intent
        - Provide confidence indicators for integrated information"""
        
        user_prompt = f"""
        Original Query: {query}
        
        Retrieved Knowledge:
        {self._format_retrieved_knowledge(retrieved_knowledge)}
        
        Please create an enhanced prompt that integrates the retrieved knowledge effectively while addressing the original query.
        Include reasoning for how the retrieved knowledge enhances the response.
        """
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        response_content = self._call_openai(messages)
        confidence = self._calculate_rag_confidence(retrieved_knowledge, response_content)
        
        return AgentResponse(
            success=True,
            content=response_content,
            metadata={
                "agent_type": "RAGKnowledgePromptAgent",
                "knowledge_domain": knowledge_domain,
                "retrieved_sources": len(retrieved_knowledge),
                "source_details": [
                    {"source": item["source"], "relevance": item["relevance_score"]} 
                    for item in retrieved_knowledge
                ],
                "avg_relevance": sum(item["relevance_score"] for item in retrieved_knowledge) / len(retrieved_knowledge) if retrieved_knowledge else 0
            },
            confidence_score=confidence,
            reasoning=f"Enhanced prompt using RAG with {len(retrieved_knowledge)} relevant sources from {knowledge_domain}"
        )
    
    def _retrieve_knowledge(self, query: str, domain: str, max_sources: int, min_relevance: float) -> List[Dict[str, Any]]:
        """Simulate knowledge retrieval based on query and domain"""
        available_knowledge = self.knowledge_sources.get(domain, [])
        
        # Simple relevance scoring based on keyword matching
        relevant_knowledge = []
        query_words = set(query.lower().split())
        
        for item in available_knowledge:
            content_words = set(item['content'].lower().split())
            overlap = len(query_words.intersection(content_words))
            
            # Adjust relevance score based on keyword overlap
            adjusted_relevance = item['relevance_score'] * (1 + overlap * 0.1)
            
            if adjusted_relevance >= min_relevance:
                item_copy = item.copy()
                item_copy['adjusted_relevance'] = adjusted_relevance
                relevant_knowledge.append(item_copy)
        
        # Sort by relevance and return top results
        relevant_knowledge.sort(key=lambda x: x.get('adjusted_relevance', x['relevance_score']), reverse=True)
        return relevant_knowledge[:max_sources]
    
    def _format_retrieved_knowledge(self, knowledge_items: List[Dict[str, Any]]) -> str:
        """Format retrieved knowledge for prompt integration"""
        if not knowledge_items:
            return "No relevant knowledge retrieved."
        
        formatted = []
        for i, item in enumerate(knowledge_items, 1):
            relevance = item.get('adjusted_relevance', item['relevance_score'])
            formatted.append(f"{i}. {item['content']}\n   Source: {item['source']} (Relevance: {relevance:.2f})")
        
        return "\n\n".join(formatted)
    
    def _calculate_rag_confidence(self, retrieved_knowledge: List[Dict[str, Any]], response: str) -> float:
        """Calculate confidence based on retrieved knowledge quality and integration"""
        if not retrieved_knowledge:
            return 0.3
        
        # Base confidence on average relevance of retrieved sources
        avg_relevance = sum(item.get('adjusted_relevance', item['relevance_score']) for item in retrieved_knowledge) / len(retrieved_knowledge)
        
        # Adjust based on response quality
        response_quality = self._calculate_confidence(response)
        
        return (avg_relevance + response_quality) / 2
    
    def enhance_with_project_knowledge(self, query: str) -> AgentResponse:
        """Enhance query with project management knowledge"""
        return self.process({
            'query': query,
            'knowledge_domain': 'project_management_best_practices',
            'max_sources': 3,
            'min_relevance': 0.8
        })
    
    def enhance_with_technical_knowledge(self, query: str) -> AgentResponse:
        """Enhance query with technical documentation knowledge"""
        return self.process({
            'query': query,
            'knowledge_domain': 'technical_documentation',
            'max_sources': 2,
            'min_relevance': 0.85
        })
