
"""
Base Agent Class for AI-Powered Project Management Workflow
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
from pydantic import BaseModel
import openai
import os
from dotenv import load_dotenv

load_dotenv()

class AgentResponse(BaseModel):
    """Standard response format for all agents"""
    success: bool
    content: str
    metadata: Dict[str, Any] = {}
    confidence_score: float = 0.0
    reasoning: str = ""

class BaseAgent(ABC):
    """Base class for all workflow agents"""
    
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.getenv("OPENAI_API_KEY", "voc-122935425515987435402666873764590c62.49926411")
        self.client = openai.OpenAI(api_key=self.api_key)
        self.agent_name = self.__class__.__name__
        
    @abstractmethod
    def process(self, input_data: Dict[str, Any]) -> AgentResponse:
        """Process input and return structured response"""
        pass
    
    def _call_openai(self, messages: List[Dict[str, str]], model: str = "gpt-3.5-turbo", temperature: float = 0.7) -> str:
        """Helper method to call OpenAI API"""
        try:
            response = self.client.chat.completions.create(
                model=model,
                messages=messages,
                temperature=temperature,
                max_tokens=1500
            )
            return response.choices[0].message.content
        except Exception as e:
            return f"Error calling OpenAI API: {str(e)}"
    
    def _calculate_confidence(self, response_content: str) -> float:
        """Calculate confidence score based on response characteristics"""
        if not response_content or "Error" in response_content:
            return 0.1
        
        # Simple heuristic based on response length and structure
        length_score = min(len(response_content) / 500, 1.0)
        structure_score = 0.8 if any(marker in response_content.lower() 
                                   for marker in ['plan', 'step', 'action', 'recommendation']) else 0.5
        
        return (length_score + structure_score) / 2
