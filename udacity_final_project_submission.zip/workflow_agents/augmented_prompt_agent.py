
"""
Augmented Prompt Agent - Enhances prompts with context and structure
"""

from typing import Dict, Any, List
from .base_agent import BaseAgent, AgentResponse

class AugmentedPromptAgent(BaseAgent):
    """
    Enhances prompts with additional context, structure, and optimization techniques:
    - Adds relevant context and background information
    - Structures prompts for better AI comprehension
    - Applies prompt engineering best practices
    - Optimizes for specific task types and domains
    """
    
    def process(self, input_data: Dict[str, Any]) -> AgentResponse:
        """
        Process prompt augmentation requests
        
        Args:
            input_data: Dictionary containing:
                - original_prompt: The base prompt to enhance
                - task_domain: Domain context (e.g., 'project_management', 'technical', 'creative')
                - target_audience: Intended audience for the response
                - enhancement_type: Type of enhancement needed
        """
        original_prompt = input_data.get('original_prompt', '')
        task_domain = input_data.get('task_domain', 'general')
        target_audience = input_data.get('target_audience', 'general')
        enhancement_type = input_data.get('enhancement_type', 'comprehensive')
        
        system_prompt = """You are an expert in prompt engineering and AI communication optimization. 
        Your role is to enhance prompts to make them more effective, structured, and likely to produce high-quality responses.
        
        Enhancement techniques you should apply:
        - Add relevant context and background
        - Structure with clear sections and formatting
        - Include specific instructions and constraints
        - Add examples when helpful
        - Specify desired output format
        - Include role-playing elements when appropriate
        - Add quality criteria and success metrics"""
        
        user_prompt = f"""
        Please enhance the following prompt for optimal AI interaction:
        
        Original Prompt: {original_prompt}
        
        Task Domain: {task_domain}
        Target Audience: {target_audience}
        Enhancement Type: {enhancement_type}
        
        Provide an enhanced version that will produce more accurate, comprehensive, and useful responses.
        Include your reasoning for the enhancements made.
        """
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        response_content = self._call_openai(messages)
        confidence = self._calculate_confidence(response_content)
        
        return AgentResponse(
            success=True,
            content=response_content,
            metadata={
                "agent_type": "AugmentedPromptAgent",
                "original_prompt_length": len(original_prompt),
                "task_domain": task_domain,
                "enhancement_type": enhancement_type
            },
            confidence_score=confidence,
            reasoning=f"Applied prompt engineering techniques for {task_domain} domain with {enhancement_type} enhancement"
        )
    
    def enhance_for_project_management(self, prompt: str) -> AgentResponse:
        """Enhance prompt specifically for project management tasks"""
        return self.process({
            'original_prompt': prompt,
            'task_domain': 'project_management',
            'target_audience': 'technical_project_managers',
            'enhancement_type': 'structured_pm_focused'
        })
    
    def add_context_and_examples(self, prompt: str, context: str) -> AgentResponse:
        """Add context and examples to improve prompt effectiveness"""
        enhanced_prompt = f"{prompt}\n\nAdditional Context: {context}"
        return self.process({
            'original_prompt': enhanced_prompt,
            'task_domain': 'general',
            'target_audience': 'general',
            'enhancement_type': 'context_and_examples'
        })
