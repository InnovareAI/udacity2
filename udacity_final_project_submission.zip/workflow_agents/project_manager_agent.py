
"""
Project Manager Agent - Orchestrates overall project management tasks
"""

from typing import Dict, Any, List
from .base_agent import BaseAgent, AgentResponse

class ProjectManagerAgent(BaseAgent):
    """
    Orchestrates overall project management tasks including:
    - Project planning and timeline creation
    - Resource allocation and team coordination
    - Risk assessment and mitigation strategies
    - Progress tracking and reporting
    """
    
    def process(self, input_data: Dict[str, Any]) -> AgentResponse:
        """
        Process project management requests
        
        Args:
            input_data: Dictionary containing:
                - task_type: Type of PM task (planning, tracking, reporting, etc.)
                - project_details: Project information
                - requirements: Specific requirements or constraints
                - timeline: Project timeline information
        """
        task_type = input_data.get('task_type', 'general_planning')
        project_details = input_data.get('project_details', '')
        requirements = input_data.get('requirements', '')
        timeline = input_data.get('timeline', '')
        
        system_prompt = """You are an expert Technical Project Manager with extensive experience in software development and AI projects. 
        You excel at creating comprehensive project plans, managing resources, identifying risks, and ensuring successful project delivery.
        
        Your responses should be structured, actionable, and include:
        - Clear project breakdown and milestones
        - Resource requirements and allocation
        - Risk assessment with mitigation strategies
        - Timeline with dependencies
        - Success metrics and deliverables"""
        
        user_prompt = f"""
        Task Type: {task_type}
        
        Project Details: {project_details}
        
        Requirements: {requirements}
        
        Timeline: {timeline}
        
        Please provide a comprehensive project management response that addresses the specific task type and includes actionable recommendations.
        """
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        response_content = self._call_openai(messages)
        confidence = self._calculate_confidence(response_content)
        
        return AgentResponse(
            success=True,
            content=response_content,
            metadata={
                "agent_type": "ProjectManagerAgent",
                "task_type": task_type,
                "processing_approach": "comprehensive_pm_analysis"
            },
            confidence_score=confidence,
            reasoning=f"Applied project management best practices for {task_type} with focus on deliverable outcomes"
        )
    
    def create_project_plan(self, project_description: str, constraints: Dict[str, Any] = None) -> AgentResponse:
        """Create a detailed project plan"""
        return self.process({
            'task_type': 'project_planning',
            'project_details': project_description,
            'requirements': str(constraints or {}),
            'timeline': 'To be determined based on scope'
        })
    
    def assess_project_risks(self, project_details: str) -> AgentResponse:
        """Assess project risks and provide mitigation strategies"""
        return self.process({
            'task_type': 'risk_assessment',
            'project_details': project_details,
            'requirements': 'Identify technical, resource, and timeline risks',
            'timeline': 'Current project phase'
        })
